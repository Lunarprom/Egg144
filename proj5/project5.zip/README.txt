Q1:For which communication(s) do you use the SSL encryption?
(4)->(5)
(5)->(6)

Q2:How do you ensure that the item was purchased exactly at the Buy_Price of that particular item? 
The Buy_Price data will not be stored in the client, but instead transmitted from the database to the server directly. Therefore the user is not able to get access to the data nor able to tamper it. 